# Plastic Waste Type > 2023-12-18 5:38am
https://universe.roboflow.com/recy-clear-dtsm5/plastic-waste-type

Provided by a Roboflow user
License: CC BY 4.0

